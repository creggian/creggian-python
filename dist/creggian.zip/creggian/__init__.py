__all__ = ["main"]

from creggian.main import *
